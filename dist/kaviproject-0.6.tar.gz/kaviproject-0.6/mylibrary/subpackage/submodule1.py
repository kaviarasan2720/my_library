def sub_function1():
    print("This is submodule function 1")
def length(val):
    ''''
    #length~
    over all length get use the fuction mecure the leanth
    '''
    count=0
    for i in val:
        count=count+1
    return count
def sub_function2():
    print("This is submodule function 2")
