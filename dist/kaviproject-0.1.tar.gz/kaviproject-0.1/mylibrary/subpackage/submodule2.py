class MySubClass:
    def __init__(self, name):
        self.name = name

    def sub_greet(self):
        print("Hello from subpackage,", self.name)
