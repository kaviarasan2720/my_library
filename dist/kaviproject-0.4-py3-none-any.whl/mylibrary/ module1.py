def function1():
    print("This is function 1")

def leanth(val):
    ''''
    #leanth~
    over all leanth get use the fuction mecure the leanth
    '''
    count=0
    for i in val:
        count=count+1
    return count

def function2():
    print("This is function 2")
