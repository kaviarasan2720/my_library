def sub_function1():
    print("This is submodule function 1")

def sub_function2():
    print("This is submodule function 2")
